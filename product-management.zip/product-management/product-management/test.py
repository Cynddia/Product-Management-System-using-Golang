import boto3
import base64
from io import BytesIO
from PIL import Image
import requests

# S3 client
s3 = boto3.client('s3', aws_access_key_id='AKIAV34TM6T7YCHE3SFY', aws_secret_access_key='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')

# Decoding Base64
def upload_to_s3(base64_data, bucket_name, object_name):
    try:
        # Decode Base64 to binary
        image_data = base64.b64decode(base64_data.split(',')[1])
        image = Image.open(BytesIO(image_data))
        buffer = BytesIO()
        image.save(buffer, format="JPEG")
        buffer.seek(0)

        # Upload to S3
        s3.upload_fileobj(buffer, bucket_name, object_name)
        print(f"Uploaded {object_name} to bucket {bucket_name}")
    except Exception as e:
        print("Error uploading image:", e)
def download_image(url):
    # Download the image from the URL
    response = requests.get(url)
    return response.content

# Example Usage
image_url = "https://images.pexels.com/photos/56866/garden-rose-red-pink-56866.jpeg?cs=srgb&dl=pexels-pixabay-56866.jpg&fm=jpg"  # Replace with your image URL
image_data = download_image(image_url)
base64_image = base64.b64encode(image_data).decode('utf-8')
upload_to_s3(f"data:image/jpeg;base64,{base64_image}", 'cynddiabucket', 'https://ap-south-1.console.aws.amazon.com/s3/buckets/cynddiabucket?region=ap-south-1&bucketType=general&tab=objects')
